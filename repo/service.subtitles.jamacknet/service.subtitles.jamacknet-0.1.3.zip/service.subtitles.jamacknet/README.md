# sub_Jamacknet
kodi subtitle addon for Jamack.net

This is kodi(xbmc) subtitle addon for Jamack.net subtitle site.
