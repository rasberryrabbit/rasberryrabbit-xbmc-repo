# service.subtitles.jamak
get subtitle from jamak.kr
