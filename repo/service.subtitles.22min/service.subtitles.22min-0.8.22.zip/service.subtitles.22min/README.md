# sub_22min
kodi subtitle addon for 22min.com

This is kodi(xbmc) subtitle addon for 22min.com subtitle search site.
