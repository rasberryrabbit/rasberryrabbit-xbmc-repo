# sub_nScreen
kodi subtitle addon for nScreen.info

This is Kodi(xbmc) subtitle addon for nScreen.info site.

